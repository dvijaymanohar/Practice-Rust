#[cfg(feature = "graphical_debug")]
pub mod graphical_debug;
pub mod uart_16550;
