#!/bin/bash
sudo apt-get install build-essential autoconf2.64 automake1.11 gcc-multilib libtool texinfo gperf bison flex libssl-dev python-minimal cmake ccache
