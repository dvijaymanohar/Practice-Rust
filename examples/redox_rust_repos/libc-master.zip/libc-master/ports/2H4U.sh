#!/bin/bash
source environ.sh

UNSTABLE

SRC=http://sourceforge.net/projects/toohardforyou/files/2H4U/2H4U%20v1.3/2H4U-1.3_SOURCES.tar.gz
DIR=2H4U

MAKE_DIR=scripts
make_template $*
