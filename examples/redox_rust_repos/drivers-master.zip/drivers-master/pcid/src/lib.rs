//! Interface to `pcid`.

mod driver_interface;
mod pci;
pub use driver_interface::*;
